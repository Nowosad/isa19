options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE, fig.height = 5, echo = TRUE)
knitr::opts_chunk$set(root.dir = normalizePath("."))

library(raster)
library(dplyr)
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))

study_area = raster(ncol = 101, nrow = 101, 
                    xmn = -113.0737,
                    xmx = -112.9896,
                    ymn = 37.26292,
                    ymx = 37.34708,
                    vals = 1)



srtm[study_area]

srtm[study_area, drop = FALSE]



srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
data("zion_points", package = "spDataLarge")



zion_points$elevation = raster::extract(srtm, zion_points)
zion_points

elevation_buffer = raster::extract(srtm, zion_points, buffer = 1000)
str(elevation_buffer)

zion_transect = cbind(c(-113.2, -112.9), c(37.45, 37.2)) %>%
  st_linestring() %>% 
  st_sfc(crs = projection(srtm)) %>% 
  st_sf()



transect = raster::extract(srtm, zion_transect, 
                           along = TRUE, cellnumbers = TRUE)
transect

transect_df = purrr::map_dfr(transect, as_data_frame, .id = "ID")
transect_coords = xyFromCell(srtm, transect_df$cell)
pair_dist = geosphere::distGeo(transect_coords)[-nrow(transect_coords)]
transect_df$dist = c(0, cumsum(pair_dist)) 

zion = st_read(system.file("vector/zion.gpkg", package = "spDataLarge"))
zion = st_transform(zion, projection(srtm))
zion_srtm_values = raster::extract(x = srtm, y = zion, df = TRUE) 



zion_srtm_values = raster::extract(x = srtm, y = zion, df = TRUE) 

zion_srtm_values %>% 
  group_by(ID) %>% 
  summarize_at(vars(srtm), list(~min(.), ~mean(.), ~max(.)))

library(spDataLarge)
zion_nlcd = raster::extract(nlcd, zion, df = TRUE, factors = TRUE) 
dplyr::select(zion_nlcd, ID, levels) %>% 
  tidyr::gather(key, value, -ID) %>%
  group_by(ID, key, value) %>%
  tally() %>% 
  tidyr::spread(value, n, fill = 0)
