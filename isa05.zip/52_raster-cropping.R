options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE, fig.height = 5, echo = TRUE)
knitr::opts_chunk$set(root.dir = normalizePath("."))

library(sf)
library(raster)
library(spData)
library(spDataLarge)
nz
nz_elev
otago = subset(nz, Name == "Otago")



nz_elev_cropped = crop(nz_elev, otago)



nz_elev_masked = mask(nz_elev, otago)



nz_elev_cropped = crop(nz_elev, otago)
nz_elev_masked2 = mask(nz_elev_cropped, otago)
