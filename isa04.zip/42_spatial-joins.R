options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE, fig.height = 5, echo = TRUE)
knitr::opts_chunk$set(root.dir = normalizePath("."))

library(sf)
library(dplyr)
library(spData)



## nz
## nz_height

nz_height2 = st_join(nz_height, nz)
dim(nz_height)
dim(nz_height2)

nz2 = st_join(nz, nz_height)
dim(nz)
dim(nz2)



## cycle_hire
## cycle_hire_osm

cycle_hire_27700 = st_transform(cycle_hire, 27700)
cycle_hire_osm_27700 = st_transform(cycle_hire_osm, 27700)
sel = st_is_within_distance(cycle_hire_27700, cycle_hire_osm_27700, dist = 20)

cycle_hire_27700_2 = st_join(cycle_hire_27700, cycle_hire_osm_27700,
                             join = st_is_within_distance, dist = 20)

nrow(cycle_hire)
nrow(cycle_hire_27700_2)

cycle_hire_27700_2 = cycle_hire_27700_2 %>% 
  group_by(id) %>% 
  summarize(capacity = mean(capacity))



library(raster)
aut = getData("alt", country = "AUT", mask = TRUE)
che = getData("alt", country = "CHE", mask = TRUE)



aut_che = merge(aut, che)





library(spDataLarge)
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
nlcd

stack(srtm, nlcd)

projection(srtm)
projection(nlcd)

bbox(srtm)
bbox(nlcd)

res(srtm)
res(nlcd)

srtm2 = projectRaster(srtm, nlcd, method = "bilinear")

projection(srtm2)
projection(nlcd)

bbox(srtm2)
bbox(nlcd)

res(srtm2)
res(nlcd)

stack(srtm2, nlcd)
