options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE, fig.height = 5, echo = TRUE)
knitr::opts_chunk$set(root.dir = normalizePath("."))

library(sf)
library(dplyr)
library(spData)
world_sum = world %>% 
  summarize(pop = sum(pop, na.rm = TRUE), n = n())

world_agg = world %>%
  group_by(continent) %>%
  summarize(pop = sum(pop, na.rm = TRUE))



library(raster)
library(spDataLarge)
srtm = raster(system.file("raster/srtm.tif", package = "spDataLarge"))
srtm_agg = aggregate(srtm, fact = 10, fun = mean)
res(srtm)
res(srtm_agg)



srtm_disagg = disaggregate(srtm_agg, fact = 10, method = "bilinear")
