options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE)
knitr::opts_chunk$set(root.dir = normalizePath("."))

library(sf)
library(dplyr)
library(spData)
library(units)

seine$lenght = st_length(seine)
seine$lenght = set_units(st_length(seine), "km")
seine$lenght = as.numeric(st_length(seine))

st_length(nz)
nz2 = nz %>% st_cast("MULTILINESTRING")
st_length(nz2)
nz$perimeter = st_length(nz2)

nz$area = st_area(nz)
nz$area = set_units(st_area(nz), "km2")
nz$area = as.numeric(st_area(nz))

library(raster)
library(spDataLarge)

nz_elev

length(na.omit(nz_elev[]))

length(na.omit(nz_elev[])) * res(nz_elev)[1] * res(nz_elev)[2] 

length(na.omit(nz_elev[])) * res(nz_elev)[1] * res(nz_elev)[2] / 1000000

nlcd

freq_nlcd = freq(nlcd)
freq_nlcd = as.data.frame(freq_nlcd)
freq_nlcd$area_m2 = freq_nlcd$count * res(nlcd)[1] * res(nlcd)[2]
freq_nlcd$area_km2 = freq_nlcd$area_m2 / 1000000
freq_nlcd
# ?zonal
