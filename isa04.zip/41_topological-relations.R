options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE, echo = TRUE, fig.height = 5)
knitr::opts_chunk$set(root.dir = normalizePath("."))

library(sf)
library(dplyr)
library(spData)
canterbury = nz %>% filter(Name == "Canterbury")





st_intersects(nz_height, canterbury)

st_intersects(nz_height, canterbury, sparse = FALSE)

# 1
canterbury_height = nz_height[canterbury, ]



# 2
sel_sgbp = st_intersects(x = nz_height, y = canterbury)
sel_logical = lengths(sel_sgbp) > 0
canterbury_height2 = nz_height[sel_logical, ]



# 3
canterbury_height3 = nz_height %>%
  dplyr::filter(st_intersects(x = ., y = canterbury, sparse = FALSE))



?st_intersects

nz_height[canterbury, , op = st_disjoint]

nz_height = nz_height %>% arrange(-elevation)
nz_heighest = nz_height[1, ]
nz_height_rest = nz_height[-1, ]

nz_heighest

nz_height_rest

st_distance(nz_heighest, nz_height_rest)

sel = st_is_within_distance(nz_heighest, nz_height_rest, dist = 10000)
sel

sel2 = st_is_within_distance(nz_height_rest, nz_heighest, dist = 1000, sparse = FALSE)
head(sel2)
canterbury_height3 = nz_height_rest %>%
  dplyr::filter(sel2)
canterbury_height3
