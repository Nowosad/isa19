options(htmltools.dir.version = FALSE)
knitr::opts_chunk$set(fig.align = "center", cache = FALSE)
knitr::opts_chunk$set(root.dir = normalizePath("."))

library(sf)
library(dplyr)
library(spData)

world

glimpse(world)

world[, 1:3]

world[, c("name_long", "lifeExp")]

world %>% dplyr::select(name_long, lifeExp)

## world1 = dplyr::select(world, name_long, pop)
## world2 = dplyr::select(world, name_long:pop)
## world3 = dplyr::select(world, -subregion, -area_km2)
## world4 = dplyr::select(world, name_long, population = pop)
## ?dplyr::select

world5 = st_drop_geometry(world)
world5

world[1:6, ]

small_countries = world[world$area_km2 < 10000, ]



small_countries = subset(world, area_km2 < 10000)



small_countries = world %>% filter(area_km2 < 10000)



world6 = arrange(world, pop)
world7 = arrange(world, -pop)
world7

world8 = arrange(world, -pop) %>%
  slice(1:5)



world$pop

world %>% pull(pop)

library(raster)
library(spData)
library(spDataLarge)

plot(elev)
dim(elev)
as.matrix(elev)


plot(elevation)
dim(elevation)
ncol(elevation)
nrow(elevation)
nlayers(elevation)

elevation2 = elevation[c(1:457), c(1:200)]
elevation2

elevation3 = elevation[1:100]
elevation3

elevation4 = elevation > 2500
plot(elevation4)

elevation5 = elevation[elevation4]
elevation5

elevation6 = elevation[elevation > 2500]
elevation6
